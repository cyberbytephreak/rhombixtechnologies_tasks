import { FileCode, Calendar, RotateCw, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

interface AnalysisHeaderProps {
  fileName: string;
  language: string;
  createdAt: string;
  onReAnalyze?: () => void;
  onExport?: () => void;
  isAnalyzing?: boolean;
}

export function AnalysisHeader({
  fileName,
  language,
  createdAt,
  onReAnalyze,
  onExport,
  isAnalyzing,
}: AnalysisHeaderProps) {
  return (
    <Card className="p-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-4">
          <div className="p-3 rounded-lg bg-primary/10">
            <FileCode className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h2 className="text-xl font-bold" data-testid="text-analysis-filename">
              {fileName}
            </h2>
            <div className="flex items-center gap-3 text-sm text-muted-foreground mt-1">
              <span>{language}</span>
              <span>•</span>
              <div className="flex items-center gap-1">
                <Calendar className="h-3 w-3" />
                {new Date(createdAt).toLocaleDateString()} at{" "}
                {new Date(createdAt).toLocaleTimeString()}
              </div>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            onClick={onReAnalyze}
            disabled={isAnalyzing}
            data-testid="button-reanalyze"
          >
            <RotateCw className={`h-4 w-4 mr-2 ${isAnalyzing ? "animate-spin" : ""}`} />
            {isAnalyzing ? "Analyzing..." : "Re-analyze"}
          </Button>
          <Button
            variant="outline"
            onClick={onExport}
            data-testid="button-export"
          >
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>
    </Card>
  );
}
