import { Card } from "@/components/ui/card";
import {
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import type { BugStatistics } from "@shared/schema";

interface BugChartsProps {
  stats: BugStatistics;
}

const SEVERITY_COLORS = {
  critical: "hsl(0, 84%, 60%)",
  warning: "hsl(38, 92%, 50%)",
  info: "hsl(217, 91%, 60%)",
};

const TYPE_COLORS = {
  syntax: "hsl(217, 91%, 60%)",
  logic: "hsl(38, 92%, 50%)",
  security: "hsl(0, 84%, 60%)",
  performance: "hsl(142, 71%, 45%)",
  style: "hsl(280, 65%, 60%)",
};

export function BugCharts({ stats }: BugChartsProps) {
  const severityData = [
    { name: "Critical", value: stats.critical, color: SEVERITY_COLORS.critical },
    { name: "Warning", value: stats.warning, color: SEVERITY_COLORS.warning },
    { name: "Info", value: stats.info, color: SEVERITY_COLORS.info },
  ].filter((item) => item.value > 0);

  const typeData = Object.entries(stats.byType)
    .map(([type, count]) => ({
      name: type.charAt(0).toUpperCase() + type.slice(1),
      count,
      fill: TYPE_COLORS[type as keyof typeof TYPE_COLORS],
    }))
    .filter((item) => item.count > 0);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card className="p-6 animate-fade-in">
        <h3 className="text-lg font-semibold mb-4">Issues by Type</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={typeData}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
            <XAxis
              dataKey="name"
              className="text-xs"
              tick={{ fill: "hsl(var(--muted-foreground))" }}
            />
            <YAxis
              className="text-xs"
              tick={{ fill: "hsl(var(--muted-foreground))" }}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--card))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "8px",
              }}
            />
            <Bar dataKey="count" radius={[8, 8, 0, 0]} animationDuration={500} />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      <Card className="p-6 animate-fade-in" style={{ animationDelay: "0.1s" }}>
        <h3 className="text-lg font-semibold mb-4">Severity Distribution</h3>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie
              data={severityData}
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={100}
              paddingAngle={5}
              dataKey="value"
              animationBegin={0}
              animationDuration={500}
            >
              {severityData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--card))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "8px",
              }}
            />
            <Legend
              wrapperStyle={{ fontSize: "14px" }}
              iconType="circle"
            />
          </PieChart>
        </ResponsiveContainer>
      </Card>
    </div>
  );
}
