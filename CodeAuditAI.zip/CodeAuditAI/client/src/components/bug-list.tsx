import { AlertCircle, AlertTriangle, Info, ChevronRight } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import type { Bug } from "@shared/schema";
import { useState } from "react";

interface BugListProps {
  bugs: Bug[];
  onBugClick?: (bug: Bug) => void;
}

const SEVERITY_CONFIG = {
  critical: {
    icon: AlertCircle,
    color: "text-destructive",
    bgColor: "bg-destructive/10",
    badgeVariant: "destructive" as const,
  },
  warning: {
    icon: AlertTriangle,
    color: "text-yellow-500",
    bgColor: "bg-yellow-500/10",
    badgeVariant: "secondary" as const,
  },
  info: {
    icon: Info,
    color: "text-primary",
    bgColor: "bg-primary/10",
    badgeVariant: "secondary" as const,
  },
};

const TYPE_LABELS = {
  syntax: "Syntax Error",
  logic: "Logic Bug",
  security: "Security Issue",
  performance: "Performance",
  style: "Code Style",
};

export function BugList({ bugs, onBugClick }: BugListProps) {
  const [expandedBugs, setExpandedBugs] = useState<Set<string>>(new Set());

  const toggleBug = (bugId: string) => {
    setExpandedBugs((prev) => {
      const next = new Set(prev);
      if (next.has(bugId)) {
        next.delete(bugId);
      } else {
        next.add(bugId);
      }
      return next;
    });
  };

  if (bugs.length === 0) {
    return (
      <Card className="p-12">
        <div className="text-center">
          <div className="mx-auto w-16 h-16 rounded-full bg-green-500/10 flex items-center justify-center mb-4">
            <Info className="h-8 w-8 text-green-500" />
          </div>
          <h3 className="text-lg font-semibold mb-2">No issues found!</h3>
          <p className="text-muted-foreground">
            Your code looks clean. Great job!
          </p>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-6">
      <h3 className="text-lg font-semibold mb-4">
        Detected Issues ({bugs.length})
      </h3>
      <div className="space-y-2">
        {bugs.map((bug, index) => {
          const config = SEVERITY_CONFIG[bug.severity as keyof typeof SEVERITY_CONFIG];
          const Icon = config.icon;
          const isExpanded = expandedBugs.has(bug.id);

          return (
            <Collapsible
              key={bug.id}
              open={isExpanded}
              onOpenChange={() => toggleBug(bug.id)}
            >
              <div
                className={`
                  rounded-lg border transition-all
                  ${isExpanded ? "bg-card-border/30" : "hover-elevate"}
                `}
                data-testid={`bug-item-${index}`}
              >
                <CollapsibleTrigger asChild>
                  <div
                    className="flex items-start gap-3 p-4 cursor-pointer w-full"
                    onClick={() => onBugClick?.(bug)}
                  >
                    <div className={`p-2 rounded-lg ${config.bgColor} flex-shrink-0`}>
                      <Icon className={`h-4 w-4 ${config.color}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <Badge variant={config.badgeVariant}>
                          {bug.severity.toUpperCase()}
                        </Badge>
                        <Badge variant="outline">
                          {TYPE_LABELS[bug.type as keyof typeof TYPE_LABELS]}
                        </Badge>
                        <span className="text-sm text-muted-foreground">
                          Line {bug.line}
                        </span>
                      </div>
                      <p className="font-medium text-sm">{bug.message}</p>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="flex-shrink-0"
                    >
                      <ChevronRight
                        className={`h-5 w-5 transition-transform ${
                          isExpanded ? "rotate-90" : ""
                        }`}
                      />
                    </Button>
                  </div>
                </CollapsibleTrigger>
                <CollapsibleContent>
                  <div className="px-4 pb-4 pt-2 space-y-3 border-t">
                    <div>
                      <p className="text-sm font-medium mb-1">Description</p>
                      <p className="text-sm text-muted-foreground">
                        {bug.description}
                      </p>
                    </div>
                    {bug.suggestion && (
                      <div>
                        <p className="text-sm font-medium mb-1">
                          💡 AI Suggestion
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {bug.suggestion}
                        </p>
                      </div>
                    )}
                  </div>
                </CollapsibleContent>
              </div>
            </Collapsible>
          );
        })}
      </div>
    </Card>
  );
}
