import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import type { Bug } from "@shared/schema";

interface CodeViewerProps {
  code: string;
  language: string;
  bugs: Bug[];
  highlightLine?: number;
}

export function CodeViewer({ code, language, bugs, highlightLine }: CodeViewerProps) {
  const lines = code.split("\n");

  const getBugForLine = (lineNum: number) => {
    return bugs.filter((bug) => bug.line === lineNum);
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical":
        return "bg-destructive/20 border-l-4 border-l-destructive";
      case "warning":
        return "bg-yellow-500/20 border-l-4 border-l-yellow-500";
      case "info":
        return "bg-primary/20 border-l-4 border-l-primary";
      default:
        return "";
    }
  };

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold">Code Preview</h3>
        <span className="text-sm text-muted-foreground">{language}</span>
      </div>
      <ScrollArea className="h-[500px] w-full">
        <div className="font-mono text-sm">
          {lines.map((line, index) => {
            const lineNum = index + 1;
            const lineBugs = getBugForLine(lineNum);
            const hasBug = lineBugs.length > 0;
            const isHighlighted = highlightLine === lineNum;
            const severityColor = hasBug
              ? getSeverityColor(lineBugs[0].severity)
              : "";

            return (
              <div
                key={index}
                className={`
                  flex group transition-colors
                  ${hasBug ? severityColor : ""}
                  ${isHighlighted ? "bg-primary/10" : ""}
                  ${!hasBug && !isHighlighted ? "hover:bg-muted/50" : ""}
                `}
                data-testid={`code-line-${lineNum}`}
              >
                <span className="select-none text-muted-foreground px-4 py-1 min-w-[4rem] text-right">
                  {lineNum}
                </span>
                <pre className="flex-1 px-4 py-1 overflow-x-auto">
                  <code>{line || " "}</code>
                </pre>
              </div>
            );
          })}
        </div>
      </ScrollArea>
    </Card>
  );
}
