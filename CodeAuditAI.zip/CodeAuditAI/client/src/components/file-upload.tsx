import { useCallback, useState } from "react";
import { Upload, FileCode, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface FileUploadProps {
  onFileSelect: (file: File, content: string) => void;
  isAnalyzing?: boolean;
}

const SUPPORTED_LANGUAGES = {
  js: "JavaScript",
  jsx: "JavaScript",
  ts: "TypeScript",
  tsx: "TypeScript",
  py: "Python",
  java: "Java",
  cpp: "C++",
  c: "C",
  cs: "C#",
  go: "Go",
  rs: "Rust",
  php: "PHP",
  rb: "Ruby",
  swift: "Swift",
  kt: "Kotlin",
};

export function FileUpload({ onFileSelect, isAnalyzing }: FileUploadProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const getFileExtension = (filename: string) => {
    return filename.split(".").pop()?.toLowerCase() || "";
  };

  const isSupported = (filename: string) => {
    const ext = getFileExtension(filename);
    return ext in SUPPORTED_LANGUAGES;
  };

  const handleFile = useCallback(
    async (file: File) => {
      if (!isSupported(file.name)) {
        alert("Unsupported file type. Please upload a code file.");
        return;
      }

      setSelectedFile(file);
      const content = await file.text();
      onFileSelect(file, content);
    },
    [onFileSelect]
  );

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);

      const files = Array.from(e.dataTransfer.files);
      if (files.length > 0) {
        handleFile(files[0]);
      }
    },
    [handleFile]
  );

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleFileInput = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const files = e.target.files;
      if (files && files.length > 0) {
        handleFile(files[0]);
      }
    },
    [handleFile]
  );

  const clearFile = () => {
    setSelectedFile(null);
  };

  return (
    <Card className="p-8">
      <div
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        className={`
          relative border-2 border-dashed rounded-lg p-12 transition-all
          ${isDragging ? "border-primary bg-primary/5" : "border-border"}
          ${isAnalyzing ? "opacity-50 pointer-events-none" : "hover-elevate"}
        `}
        data-testid="dropzone-upload"
      >
        <input
          type="file"
          id="file-upload"
          className="hidden"
          onChange={handleFileInput}
          accept=".js,.jsx,.ts,.tsx,.py,.java,.cpp,.c,.cs,.go,.rs,.php,.rb,.swift,.kt"
          disabled={isAnalyzing}
          data-testid="input-file"
        />

        {selectedFile ? (
          <div className="flex items-center justify-between gap-4 animate-fade-in">
            <div className="flex items-center gap-3 flex-1 min-w-0">
              <FileCode className="h-8 w-8 text-primary flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="font-medium truncate" data-testid="text-filename">
                  {selectedFile.name}
                </p>
                <p className="text-sm text-muted-foreground">
                  {(selectedFile.size / 1024).toFixed(2)} KB •{" "}
                  {SUPPORTED_LANGUAGES[getFileExtension(selectedFile.name) as keyof typeof SUPPORTED_LANGUAGES]}
                </p>
              </div>
            </div>
            {!isAnalyzing && (
              <Button
                variant="ghost"
                size="icon"
                onClick={clearFile}
                data-testid="button-clear-file"
              >
                <X className="h-5 w-5" />
              </Button>
            )}
          </div>
        ) : (
          <label
            htmlFor="file-upload"
            className="flex flex-col items-center gap-4 cursor-pointer"
          >
            <div className="p-4 rounded-full bg-primary/10">
              <Upload className="h-8 w-8 text-primary" />
            </div>
            <div className="text-center">
              <p className="text-lg font-medium">
                Drop your code file here or click to browse
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                Supports JavaScript, TypeScript, Python, Java, C++, and more
              </p>
            </div>
            <div className="flex flex-wrap gap-2 justify-center mt-2">
              {Object.values(SUPPORTED_LANGUAGES)
                .filter((v, i, a) => a.indexOf(v) === i)
                .slice(0, 6)
                .map((lang) => (
                  <Badge key={lang} variant="secondary">
                    {lang}
                  </Badge>
                ))}
            </div>
          </label>
        )}
      </div>
    </Card>
  );
}
