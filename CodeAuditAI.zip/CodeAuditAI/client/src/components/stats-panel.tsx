import { Bug, ShieldAlert, AlertTriangle, Info, TrendingUp } from "lucide-react";
import { Card } from "@/components/ui/card";
import type { BugStatistics } from "@shared/schema";

interface StatsPanelProps {
  stats: BugStatistics;
  qualityScore: number;
}

export function StatsPanel({ stats, qualityScore }: StatsPanelProps) {
  const statCards = [
    {
      label: "Total Issues",
      value: stats.total,
      icon: Bug,
      color: "text-primary",
      testId: "stat-total",
    },
    {
      label: "Critical",
      value: stats.critical,
      icon: ShieldAlert,
      color: "text-destructive",
      testId: "stat-critical",
    },
    {
      label: "Warnings",
      value: stats.warning,
      icon: AlertTriangle,
      color: "text-yellow-500",
      testId: "stat-warning",
    },
    {
      label: "Quality Score",
      value: qualityScore,
      icon: TrendingUp,
      color: qualityScore >= 70 ? "text-green-500" : qualityScore >= 40 ? "text-yellow-500" : "text-destructive",
      suffix: "%",
      testId: "stat-quality",
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {statCards.map((stat, index) => {
        const Icon = stat.icon;
        return (
          <Card
            key={stat.label}
            className="p-6 animate-count-up hover-elevate"
            style={{ animationDelay: `${index * 0.1}s` }}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">
                  {stat.label}
                </p>
                <p
                  className={`text-3xl font-bold mt-2 ${stat.color}`}
                  data-testid={stat.testId}
                >
                  {stat.value}
                  {stat.suffix || ""}
                </p>
              </div>
              <div className={`p-3 rounded-lg bg-card-border/50`}>
                <Icon className={`h-6 w-6 ${stat.color}`} />
              </div>
            </div>
          </Card>
        );
      })}
    </div>
  );
}
