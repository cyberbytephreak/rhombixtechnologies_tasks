import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { FileUpload } from "@/components/file-upload";
import { StatsPanel } from "@/components/stats-panel";
import { BugCharts } from "@/components/bug-charts";
import { BugList } from "@/components/bug-list";
import { CodeViewer } from "@/components/code-viewer";
import { AnalysisHeader } from "@/components/analysis-header";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { AnalysisResult, BugStatistics, Bug } from "@shared/schema";

export default function Home() {
  const [selectedFile, setSelectedFile] = useState<{ file: File; content: string } | null>(null);
  const [currentAnalysisId, setCurrentAnalysisId] = useState<string | null>(null);
  const [highlightedLine, setHighlightedLine] = useState<number | undefined>();
  const { toast } = useToast();

  const analyzeMutation = useMutation({
    mutationFn: async (data: { fileName: string; content: string }) => {
      const response = await apiRequest("POST", "/api/analyze", data);
      return await response.json() as AnalysisResult;
    },
    onSuccess: (data) => {
      setCurrentAnalysisId(data.id);
      queryClient.invalidateQueries({ queryKey: ["/api/analyses"] });
      toast({
        title: "Analysis Complete!",
        description: `Found ${data.bugs.length} issue${data.bugs.length !== 1 ? "s" : ""} in your code.`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Analysis Failed",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    },
  });

  const { data: currentAnalysis } = useQuery<AnalysisResult>({
    queryKey: ["/api/analyses", currentAnalysisId],
    enabled: !!currentAnalysisId,
  });

  const handleFileSelect = (file: File, content: string) => {
    setSelectedFile({ file, content });
    analyzeMutation.mutate({
      fileName: file.name,
      content,
    });
  };

  const handleReAnalyze = () => {
    if (selectedFile) {
      analyzeMutation.mutate({
        fileName: selectedFile.file.name,
        content: selectedFile.content,
      });
    }
  };

  const handleExport = () => {
    if (currentAnalysis) {
      const exportData = {
        fileName: currentAnalysis.fileName,
        language: currentAnalysis.language,
        qualityScore: currentAnalysis.qualityScore,
        bugs: currentAnalysis.bugs,
        exportedAt: new Date().toISOString(),
      };

      const blob = new Blob([JSON.stringify(exportData, null, 2)], {
        type: "application/json",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${currentAnalysis.fileName}-analysis.json`;
      a.click();
      URL.revokeObjectURL(url);

      toast({
        title: "Export Successful",
        description: "Analysis report has been downloaded.",
      });
    }
  };

  const handleBugClick = (bug: Bug) => {
    setHighlightedLine(bug.line);
    setTimeout(() => setHighlightedLine(undefined), 2000);
  };

  const calculateStats = (bugs: Bug[]): BugStatistics => {
    return {
      total: bugs.length,
      critical: bugs.filter((b) => b.severity === "critical").length,
      warning: bugs.filter((b) => b.severity === "warning").length,
      info: bugs.filter((b) => b.severity === "info").length,
      byType: {
        syntax: bugs.filter((b) => b.type === "syntax").length,
        logic: bugs.filter((b) => b.type === "logic").length,
        security: bugs.filter((b) => b.type === "security").length,
        performance: bugs.filter((b) => b.type === "performance").length,
        style: bugs.filter((b) => b.type === "style").length,
      },
    };
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto p-6 space-y-6">
        <div className="text-center py-8">
          <h1 className="text-4xl font-bold mb-3">
            CodeGuard AI
          </h1>
          <p className="text-lg text-muted-foreground">
            AI-Powered Code Analysis & Bug Detection
          </p>
        </div>

        {!currentAnalysis ? (
          <div className="space-y-6">
            <FileUpload
              onFileSelect={handleFileSelect}
              isAnalyzing={analyzeMutation.isPending}
            />

            {analyzeMutation.isPending && (
              <div className="flex items-center justify-center py-12">
                <div className="text-center">
                  <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto mb-4" />
                  <p className="text-lg font-medium">Analyzing your code...</p>
                  <p className="text-sm text-muted-foreground mt-2">
                    AI is scanning for bugs, vulnerabilities, and code quality issues
                  </p>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-6 animate-fade-in">
            <AnalysisHeader
              fileName={currentAnalysis.fileName}
              language={currentAnalysis.language}
              createdAt={currentAnalysis.createdAt}
              onReAnalyze={handleReAnalyze}
              onExport={handleExport}
              isAnalyzing={analyzeMutation.isPending}
            />

            <StatsPanel
              stats={calculateStats(currentAnalysis.bugs)}
              qualityScore={currentAnalysis.qualityScore}
            />

            <BugCharts stats={calculateStats(currentAnalysis.bugs)} />

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <CodeViewer
                code={currentAnalysis.codeContent}
                language={currentAnalysis.language}
                bugs={currentAnalysis.bugs}
                highlightLine={highlightedLine}
              />
              <BugList bugs={currentAnalysis.bugs} onBugClick={handleBugClick} />
            </div>

            <div className="flex justify-center pt-6">
              <Button
                variant="outline"
                size="lg"
                onClick={() => {
                  setCurrentAnalysisId(null);
                  setSelectedFile(null);
                }}
                data-testid="button-analyze-new"
              >
                Analyze New File
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
