# Design Guidelines: AI Code Bug Detection Tool

## Design Approach
**Selected Approach:** Design System - Modern Developer Tools  
**References:** VS Code, GitHub Dashboard, Linear, Vercel  
**Justification:** Developer-focused utility application requiring efficiency, information density, and professional credibility. The design prioritizes readability, quick scanning, and seamless workflows over visual flair.

**Core Principles:**
- Performance-first: Fast loading, responsive interactions
- Information hierarchy: Clear visual prioritization of critical bugs
- Developer familiarity: Use patterns developers already know
- Dark-first design: Primary experience optimized for dark mode

---

## Core Design Elements

### A. Color Palette

**Dark Mode (Primary):**
- Background Base: `220 13% 9%` - Deep slate for main background
- Surface Elevated: `220 13% 12%` - Slightly lighter for cards/panels
- Surface Hover: `220 13% 15%` - Interactive element hover states
- Border Subtle: `220 13% 18%` - Dividers and borders
- Text Primary: `220 9% 96%` - Main content text
- Text Secondary: `220 9% 65%` - Supporting text, labels

**Semantic Colors:**
- Critical Error: `0 84% 60%` - Red for severe bugs
- Warning: `38 92% 50%` - Orange for warnings
- Info: `217 91% 60%` - Blue for informational messages
- Success: `142 71% 45%` - Green for clean code indicators
- Accent/Brand: `217 91% 60%` - Primary blue for CTAs and highlights

**Light Mode:**
- Background Base: `0 0% 100%` - Pure white
- Surface Elevated: `220 13% 98%` - Off-white for cards
- Text Primary: `220 13% 9%` - Dark text on light
- Borders: `220 13% 91%` - Subtle dividers

### B. Typography

**Font Families:**
- Interface: Inter (via Google Fonts CDN) - Clean, readable UI font
- Code: JetBrains Mono (via Google Fonts CDN) - Optimized monospace for code display

**Type Scale:**
- Headings H1: 2.25rem (36px), font-weight: 700
- Headings H2: 1.5rem (24px), font-weight: 600
- Headings H3: 1.25rem (20px), font-weight: 600
- Body Large: 1rem (16px), font-weight: 400
- Body Regular: 0.875rem (14px), font-weight: 400
- Code/Mono: 0.875rem (14px), font-weight: 400, line-height: 1.6

### C. Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 6, 8, 12, 16, 20, 24  
- Micro spacing (gaps, padding): p-2, p-4, gap-2
- Component spacing: p-6, p-8, m-8
- Section spacing: py-12, py-16, py-20
- Major separations: mt-24

**Grid System:**
- Dashboard: 12-column grid on desktop, single column on mobile
- Sidebar: Fixed 280px width on desktop (w-70), collapsible on mobile
- Main content: Flexible with max-w-7xl container

**Responsive Breakpoints:**
- Mobile: Base (< 768px) - Single column, stacked layout
- Tablet: md (768px+) - 2-column layouts where appropriate
- Desktop: lg (1024px+) - Full multi-column dashboard
- Wide: xl (1280px+) - Expanded spacing, larger charts

### D. Component Library

**Navigation:**
- Top header: Fixed, 64px height, contains logo, search, user profile
- Sidebar navigation: Collapsible on mobile, persistent on desktop with icons and labels
- Breadcrumbs: Show current file/analysis path

**File Upload Interface:**
- Drag-and-drop zone: Dashed border (border-dashed), hover state with accent color glow
- File type icons: Use Heroicons for document types
- Upload progress: Linear progress bar with percentage, animated fill

**Dashboard Cards:**
- Elevated surface with subtle shadow: `shadow-lg`
- Rounded corners: `rounded-xl` (12px)
- Padding: `p-6` for card body
- Header with icon + title + optional action button

**Code Editor Component:**
- Embedded Monaco Editor or similar (via CDN)
- VS Code Dark+ theme for syntax highlighting
- Error highlights: Red wavy underline (decoration)
- Line numbers: `text-secondary` color
- Gutter for error indicators

**Error List:**
- Table view with columns: Severity icon, Line number, Error type, Description, Fix suggestion
- Row hover: Subtle background change (`hover:bg-surface-elevated`)
- Severity badges: Pill-shaped with semantic colors
- Expandable rows for detailed AI suggestions

**Charts & Graphs:**
- Use Chart.js or Recharts (via CDN)
- Bar chart: Error distribution by type
- Donut chart: Severity breakdown (Critical/Warning/Info)
- Line chart: Code quality score over time
- Color scheme matches semantic colors
- Tooltips on hover with detailed data

**Statistics Panel:**
- Grid of metric cards: 2x2 on desktop, stacked on mobile
- Large number display: `text-4xl font-bold`
- Label below: `text-sm text-secondary`
- Icon accompanying each metric (Heroicons)
- Trend indicator: Small arrow up/down with percentage

**Buttons:**
- Primary: Filled with accent color, white text, `rounded-lg`, `px-6 py-3`
- Secondary: Outlined with border, transparent background
- Ghost: No border, text only, hover background
- Icon buttons: Square, 40px, centered icon

**Form Elements:**
- Consistent dark mode styling for inputs
- Floating labels or top-aligned labels
- Border on focus: Accent color glow
- Error states: Red border with error message below

### E. Animations

**Use Sparingly - Performance First:**
- Chart animations: Smooth entry animations (300ms ease) on initial render only
- Number counting: Animated count-up for statistics on page load (500ms)
- Progress bars: Smooth fill transition during file upload
- Skeleton loaders: Subtle pulse animation while loading data
- Hover states: Quick transitions (150ms) for interactive elements
- NO scroll-triggered animations, NO complex page transitions

---

## Images

**No hero image required** - This is a utility-focused dashboard application. Replace traditional hero sections with:
1. **Dashboard Header:** Quick stats banner showing total scans, bugs found, and quality score
2. **Empty States:** Use simple illustrations (Heroicons or undraw.co) for "No files uploaded yet" states
3. **Error Type Icons:** Visual indicators for different bug categories (syntax, logic, security, performance)

---

## Page Structure

**Main Dashboard Layout:**
1. **Top Navigation Bar** (fixed): Logo, search, upload button, user profile
2. **Sidebar** (persistent on desktop): Navigation links (Dashboard, History, Settings, Documentation)
3. **Main Content Area:**
   - Statistics grid (4 metric cards)
   - Charts section (2-column grid: error distribution + severity breakdown)
   - Recent scans list/table
4. **No traditional sections** - Focus on functional dashboard layout

**Analysis Results View:**
1. **File header**: Filename, language detected, scan timestamp, re-scan button
2. **Split view**: Code editor (left 60%) + Error panel (right 40%)
3. **Bottom panel**: Detailed error explanations and AI fix suggestions