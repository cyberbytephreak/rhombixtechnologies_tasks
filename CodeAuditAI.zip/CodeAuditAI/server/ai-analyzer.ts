import OpenAI from "openai";
import type { InsertBug } from "@shared/schema";

// Reference: javascript_openai integration
// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface BugAnalysisResult {
  bugs: Omit<InsertBug, "analysisId">[];
  qualityScore: number;
}

export async function analyzeCodeWithAI(
  code: string,
  fileName: string,
  language: string
): Promise<BugAnalysisResult> {
  try {
    const prompt = `You are an expert code analyzer and bug detector. Analyze the following ${language} code and identify all bugs, errors, security vulnerabilities, performance issues, and code style problems.

File: ${fileName}
Language: ${language}

Code:
\`\`\`${language}
${code}
\`\`\`

For each issue found, provide:
- severity: "critical", "warning", or "info"
- type: "syntax", "logic", "security", "performance", or "style"
- line: the line number where the issue occurs
- column: the column number (optional, can be null)
- message: a brief summary of the issue
- description: a detailed explanation of the problem
- suggestion: an AI-generated fix or recommendation

Also calculate an overall quality score from 0-100 where:
- 90-100: Excellent code quality
- 70-89: Good code with minor issues
- 40-69: Moderate issues that should be addressed
- 0-39: Poor code quality with critical issues

Return your analysis in JSON format with this structure:
{
  "bugs": [
    {
      "severity": "critical" | "warning" | "info",
      "type": "syntax" | "logic" | "security" | "performance" | "style",
      "line": number,
      "column": number | null,
      "message": "string",
      "description": "string",
      "suggestion": "string",
      "aiGenerated": "true"
    }
  ],
  "qualityScore": number
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content:
            "You are an expert code analyzer specializing in bug detection, security analysis, and code quality assessment. Always respond with valid JSON.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 8192,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");

    // Validate and sanitize the result
    const bugs = (result.bugs || []).map((bug: any) => ({
      severity: bug.severity || "info",
      type: bug.type || "style",
      line: parseInt(bug.line) || 1,
      column: bug.column ? parseInt(bug.column) : null,
      message: bug.message || "Unknown issue",
      description: bug.description || "No description provided",
      suggestion: bug.suggestion || null,
      aiGenerated: "true",
    }));

    const qualityScore = Math.max(0, Math.min(100, parseInt(result.qualityScore) || 50));

    return { bugs, qualityScore };
  } catch (error) {
    console.error("AI Analysis Error:", error);
    
    // Fallback: basic syntax check
    return {
      bugs: [
        {
          severity: "info",
          type: "style",
          line: 1,
          column: null,
          message: "AI analysis temporarily unavailable",
          description: "The AI-powered analysis service is currently unavailable. Please try again later.",
          suggestion: "Check your API configuration and ensure the OpenAI service is accessible.",
          aiGenerated: "true",
        },
      ],
      qualityScore: 50,
    };
  }
}

export function detectLanguage(fileName: string): string {
  const ext = fileName.split(".").pop()?.toLowerCase();
  const languageMap: Record<string, string> = {
    js: "JavaScript",
    jsx: "JavaScript",
    ts: "TypeScript",
    tsx: "TypeScript",
    py: "Python",
    java: "Java",
    cpp: "C++",
    c: "C",
    cs: "C#",
    go: "Go",
    rs: "Rust",
    php: "PHP",
    rb: "Ruby",
    swift: "Swift",
    kt: "Kotlin",
  };

  return languageMap[ext || ""] || "Unknown";
}
