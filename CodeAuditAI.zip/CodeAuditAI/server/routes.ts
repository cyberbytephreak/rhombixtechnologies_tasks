import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { analyzeCodeWithAI, detectLanguage } from "./ai-analyzer";
import { z } from "zod";

const analyzeRequestSchema = z.object({
  fileName: z.string().min(1),
  content: z.string().min(1),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Analyze code endpoint
  app.post("/api/analyze", async (req, res) => {
    try {
      const { fileName, content } = analyzeRequestSchema.parse(req.body);
      
      const language = detectLanguage(fileName);

      // Use AI to analyze the code
      const aiResult = await analyzeCodeWithAI(content, fileName, language);

      // Create analysis record
      const analysis = await storage.createAnalysis({
        fileName,
        language,
        codeContent: content,
        bugCount: aiResult.bugs.length,
        qualityScore: aiResult.qualityScore,
      });

      // Create bug records
      const bugs = await Promise.all(
        aiResult.bugs.map((bug) =>
          storage.createBug({
            ...bug,
            analysisId: analysis.id,
          })
        )
      );

      res.json({
        ...analysis,
        bugs,
      });
    } catch (error) {
      console.error("Analysis error:", error);
      res.status(400).json({
        message: error instanceof Error ? error.message : "Analysis failed",
      });
    }
  });

  // Get analysis with bugs
  app.get("/api/analyses/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const analysis = await storage.getAnalysisWithBugs(id);

      if (!analysis) {
        return res.status(404).json({ message: "Analysis not found" });
      }

      res.json(analysis);
    } catch (error) {
      console.error("Get analysis error:", error);
      res.status(500).json({
        message: error instanceof Error ? error.message : "Failed to get analysis",
      });
    }
  });

  // Get all analyses
  app.get("/api/analyses", async (req, res) => {
    try {
      const analyses = await storage.getAllAnalyses();
      res.json(analyses);
    } catch (error) {
      console.error("Get analyses error:", error);
      res.status(500).json({
        message: error instanceof Error ? error.message : "Failed to get analyses",
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
