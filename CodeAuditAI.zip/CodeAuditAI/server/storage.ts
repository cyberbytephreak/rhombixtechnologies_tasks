import {
  type CodeAnalysis,
  type InsertCodeAnalysis,
  type Bug,
  type InsertBug,
  type AnalysisResult,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  createAnalysis(analysis: InsertCodeAnalysis): Promise<CodeAnalysis>;
  getAnalysis(id: string): Promise<CodeAnalysis | undefined>;
  getAllAnalyses(): Promise<CodeAnalysis[]>;
  createBug(bug: InsertBug): Promise<Bug>;
  getBugsByAnalysisId(analysisId: string): Promise<Bug[]>;
  getAnalysisWithBugs(analysisId: string): Promise<AnalysisResult | undefined>;
}

export class MemStorage implements IStorage {
  private analyses: Map<string, CodeAnalysis>;
  private bugs: Map<string, Bug>;

  constructor() {
    this.analyses = new Map();
    this.bugs = new Map();
  }

  async createAnalysis(insertAnalysis: InsertCodeAnalysis): Promise<CodeAnalysis> {
    const id = randomUUID();
    const analysis: CodeAnalysis = {
      id,
      fileName: insertAnalysis.fileName,
      language: insertAnalysis.language,
      codeContent: insertAnalysis.codeContent,
      bugCount: insertAnalysis.bugCount ?? 0,
      qualityScore: insertAnalysis.qualityScore ?? 0,
      createdAt: new Date().toISOString(),
    };
    this.analyses.set(id, analysis);
    return analysis;
  }

  async getAnalysis(id: string): Promise<CodeAnalysis | undefined> {
    return this.analyses.get(id);
  }

  async getAllAnalyses(): Promise<CodeAnalysis[]> {
    return Array.from(this.analyses.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async createBug(insertBug: InsertBug): Promise<Bug> {
    const id = randomUUID();
    const bug: Bug = {
      id,
      analysisId: insertBug.analysisId,
      severity: insertBug.severity,
      type: insertBug.type,
      line: insertBug.line,
      column: insertBug.column ?? null,
      message: insertBug.message,
      description: insertBug.description,
      suggestion: insertBug.suggestion ?? null,
      aiGenerated: insertBug.aiGenerated ?? "true",
    };
    this.bugs.set(id, bug);
    return bug;
  }

  async getBugsByAnalysisId(analysisId: string): Promise<Bug[]> {
    return Array.from(this.bugs.values())
      .filter((bug) => bug.analysisId === analysisId)
      .sort((a, b) => a.line - b.line);
  }

  async getAnalysisWithBugs(analysisId: string): Promise<AnalysisResult | undefined> {
    const analysis = await this.getAnalysis(analysisId);
    if (!analysis) return undefined;

    const bugs = await this.getBugsByAnalysisId(analysisId);
    return { ...analysis, bugs };
  }
}

export const storage = new MemStorage();
