import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Code Analysis Schema
export const codeAnalyses = pgTable("code_analyses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fileName: text("file_name").notNull(),
  language: text("language").notNull(),
  codeContent: text("code_content").notNull(),
  bugCount: integer("bug_count").notNull().default(0),
  qualityScore: integer("quality_score").notNull().default(0),
  createdAt: text("created_at").notNull(),
});

// Bug Detection Schema
export const bugs = pgTable("bugs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  analysisId: varchar("analysis_id").notNull().references(() => codeAnalyses.id, { onDelete: "cascade" }),
  severity: text("severity").notNull(), // 'critical', 'warning', 'info'
  type: text("type").notNull(), // 'syntax', 'logic', 'security', 'performance', 'style'
  line: integer("line").notNull(),
  column: integer("column"),
  message: text("message").notNull(),
  description: text("description").notNull(),
  suggestion: text("suggestion"),
  aiGenerated: text("ai_generated").notNull().default('true'),
});

// Insert Schemas
export const insertCodeAnalysisSchema = createInsertSchema(codeAnalyses).omit({
  id: true,
  createdAt: true,
});

export const insertBugSchema = createInsertSchema(bugs).omit({
  id: true,
});

// Types
export type InsertCodeAnalysis = z.infer<typeof insertCodeAnalysisSchema>;
export type CodeAnalysis = typeof codeAnalyses.$inferSelect;

export type InsertBug = z.infer<typeof insertBugSchema>;
export type Bug = typeof bugs.$inferSelect;

// Frontend-only types for analysis results
export type AnalysisResult = CodeAnalysis & {
  bugs: Bug[];
};

export type BugStatistics = {
  total: number;
  critical: number;
  warning: number;
  info: number;
  byType: {
    syntax: number;
    logic: number;
    security: number;
    performance: number;
    style: number;
  };
};
