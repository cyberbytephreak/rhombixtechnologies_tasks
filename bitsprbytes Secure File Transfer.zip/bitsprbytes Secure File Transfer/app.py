import os
from flask import Flask, request, send_file, render_template, jsonify, abort
from cryptography.fernet import Fernet
import io

# --- Initialization ---
app = Flask(__name__)

# Configuration
UPLOAD_FOLDER = 'uploads_encrypted'
KEY_FILE = 'secret.key'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Ensure the upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# --- Cryptography Setup ---

def generate_key():
    """Generates a new encryption key and saves it to the key file."""
    key = Fernet.generate_key()
    with open(KEY_FILE, "wb") as key_file:
        key_file.write(key)
    return key

def load_key():
    """Loads the encryption key from the key file, generating one if it doesn't exist."""
    if not os.path.exists(KEY_FILE):
        return generate_key()
    with open(KEY_FILE, "rb") as key_file:
        return key_file.read()

# Load the encryption key and create a Fernet instance
encryption_key = load_key()
fernet = Fernet(encryption_key)

# --- Routes ---

@app.route('/')
def index():
    """Renders the main web page."""
    return render_template('index.html')

@app.route('/files')
def list_files():
    """Lists the available (encrypted) files."""
    try:
        files = [f for f in os.listdir(app.config['UPLOAD_FOLDER']) if os.path.isfile(os.path.join(app.config['UPLOAD_FOLDER'], f))]
        return jsonify(files)
    except Exception as e:
        return jsonify({"error": "Could not list directory.", "details": str(e)}), 500

@app.route('/upload', methods=['POST'])
def upload_file():
    """Handles file uploads, encrypts them, and saves them to the server."""
    if 'file' not in request.files:
        return jsonify({"error": "No file part in the request"}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No file selected for uploading"}), 400

    if file:
        try:
            # Read file data into memory
            original_data = file.read()
            
            # Encrypt the data
            encrypted_data = fernet.encrypt(original_data)
            
            # Save the encrypted data to a file
            encrypted_filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            with open(encrypted_filepath, "wb") as encrypted_file:
                encrypted_file.write(encrypted_data)
                
            return jsonify({"success": f"File '{file.filename}' encrypted and uploaded successfully."}), 201
        except Exception as e:
            return jsonify({"error": "An error occurred during upload.", "details": str(e)}), 500
    
    return jsonify({"error": "Unknown error occurred"}), 500

@app.route('/download/<filename>')
def download_file(filename):
    """Decrypts a file and sends it to the user for download."""
    try:
        encrypted_filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        
        if not os.path.exists(encrypted_filepath):
            abort(404, description="File not found.")

        # Read the encrypted file
        with open(encrypted_filepath, "rb") as encrypted_file:
            encrypted_data = encrypted_file.read()
        
        # Decrypt the data
        decrypted_data = fernet.decrypt(encrypted_data)
        
        # Send the decrypted data as an in-memory file
        return send_file(
            io.BytesIO(decrypted_data),
            as_attachment=True,
            download_name=filename
        )
    except Exception as e:
        # Handle potential decryption errors (e.g., wrong key, corrupted file)
        abort(500, description=f"Could not process file: {str(e)}")


if __name__ == '__main__':
    print("--- bitsprbytes Secure File Transfer ---")
    print(f"Encryption key loaded from: {KEY_FILE}")
    print(f"Encrypted files will be stored in: {UPLOAD_FOLDER}")
    print("Starting Flask server...")
    # Note: debug=True is for development only. Use a production WSGI server for deployment.
    app.run(host='0.0.0.0', port=5000, debug=True)
