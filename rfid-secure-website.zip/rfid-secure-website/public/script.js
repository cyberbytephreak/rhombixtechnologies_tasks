document.addEventListener('DOMContentLoaded', () => {

    // --- Scroll Reveal Animation ---
    const revealables = document.querySelectorAll('.revealable');
    if (revealables.length > 0) {
        const revealObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('revealed');
                    revealObserver.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });

        revealables.forEach(el => {
            revealObserver.observe(el);
        });
    }

    // --- Active Navigation Link Highlighting ---
    const navLinks = document.querySelectorAll('.nav-link');
    const currentPath = window.location.pathname.split('/').pop();
    navLinks.forEach(link => {
        const linkPath = link.getAttribute('href');
        if (linkPath === currentPath || (currentPath === '' && linkPath === 'index.html')) {
            link.classList.add('active');
        }
    });

    // --- AI Analyzer Logic ---
    const analyzeButton = document.getElementById('analyze-button');
    if (analyzeButton) { // This conditional check fixes the primary error.
        const buttonText = document.getElementById('button-text');
        const loadingSpinner = document.getElementById('loading-spinner');
        const urlInput = document.getElementById('url-input');
        const resultsContainer = document.getElementById('results-container');
        const aiResponseWrapper = document.getElementById('ai-response-wrapper');
        const preAnalysisMessage = document.getElementById('pre-analysis-message');
        const aiResponseContainer = document.getElementById('ai-response');
        const sourcesContainer = document.getElementById('sources-container');
        const sourcesList = document.getElementById('sources-list');
        const errorMessage = document.getElementById('error-message');

        analyzeButton.addEventListener('click', async () => {
            const urlToAnalyze = urlInput.value.trim();
            if (!urlToAnalyze) {
                showError("Please enter a URL to analyze.");
                return;
            }

            setLoading(true);
            hideError();
            aiResponseContainer.classList.add('hidden');
            preAnalysisMessage.textContent = 'Analyzing...';
            preAnalysisMessage.classList.remove('hidden');
            
            try {
                const systemPrompt = `You are a cybersecurity analyst specializing in RFID and NFC technology. Your task is to analyze the content of the provided URL and provide a concise, single-paragraph summary of the key findings related to RFID/NFC threats. Your analysis should be grounded in real-world risk, distinguishing between theoretical vulnerabilities and practical exploits. Reference the established principles of RFID security, such as EMV standards, encryption, and the difference between near-field and far-field communication.`;
                const userQuery = `Find the content at this URL: ${urlToAnalyze} and provide a single-paragraph analysis based on its content, following the system instructions.`;
                const apiKey = ""; 
                // Using the latest recommended model
                const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key=${apiKey}`;

                const payload = {
                    contents: [{ parts: [{ text: userQuery }] }],
                    tools: [{ "google_search": {} }],
                    systemInstruction: { parts: [{ text: systemPrompt }] },
                };
                
                const response = await fetch(apiUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                
                if (!response.ok) { throw new Error(`API error: ${response.status} ${response.statusText}`); }

                const result = await response.json();
                const candidate = result.candidates?.[0];

                if (candidate && candidate.content?.parts?.[0]?.text) {
                    const text = candidate.content.parts[0].text;
                    aiResponseContainer.innerHTML = `<p>${text.replace(/\n/g, '<br>')}</p>`;

                    let sources = [];
                    const groundingMetadata = candidate.groundingMetadata;
                     if (groundingMetadata && groundingMetadata.groundingAttributions) {
                        sources = groundingMetadata.groundingAttributions
                            .map(attribution => attribution.web)
                            .filter(web => web && web.uri && web.title); 
                    }
                    
                    displaySources(sources);
                    preAnalysisMessage.classList.add('hidden');
                    aiResponseContainer.classList.remove('hidden');

                } else { 
                    const errorText = result.candidates?.[0]?.finishReason || 'Invalid response from model';
                    throw new Error(`AI model could not generate content. Reason: ${errorText}`); 
                }

            } catch (error) {
                console.error("Analysis failed:", error);
                showError(`Analysis failed: ${error.message}. Please check the URL or try again later.`);
                preAnalysisMessage.textContent = 'Analysis failed.';
            } finally {
                setLoading(false);
            }
        });
        
        function setLoading(isLoading) {
            if (isLoading) {
                buttonText.style.display = 'none';
                loadingSpinner.classList.remove('hidden');
                analyzeButton.disabled = true;
            } else {
                buttonText.style.display = 'inline';
                loadingSpinner.classList.add('hidden');
                analyzeButton.disabled = false;
            }
        }

        function showError(message) {
            errorMessage.textContent = message;
            errorMessage.classList.remove('hidden');
        }

        function hideError() {
            errorMessage.classList.add('hidden');
        }

        function displaySources(sources) {
            if(sources && sources.length > 0) {
                sourcesList.innerHTML = sources.map(source => 
                    `<a href="${source.uri}" target="_blank" rel="noopener noreferrer" class="block text-blue-400 hover:underline truncate" title="${source.title}">${source.title}</a>`
                ).join('');
                sourcesContainer.classList.remove('hidden');
            } else {
                sourcesContainer.classList.add('hidden');
            }
        }
    }

    // --- Modal Logic for Threats Page ---
    const modal = document.getElementById('modal');
    if(modal) {
        const modalTitle = document.getElementById('modal-title');
        const modalBody = document.getElementById('modal-body');

        window.openModal = function(threatId) {
            const content = document.getElementById(`modal-content-${threatId}`);
            if (content) {
                modalTitle.innerHTML = content.querySelector('h2').innerHTML;
                modalBody.innerHTML = content.querySelector('p').outerHTML + (content.querySelector('ul, ol') ? content.querySelector('ul, ol').outerHTML : '');
                modal.classList.add('active');
            }
        }

        window.closeModal = function() {
            modal.classList.remove('active');
        }

        modal.addEventListener('click', (event) => {
            if (event.target === modal) {
                closeModal();
            }
        });
    }
});

