const express = require('express');
const path = require('path');
const app = express();
const port = 3000;

// This tells the server to make all files in the 'public' folder accessible.
// This is how your HTML pages will find your CSS, images, and other JS files.
app.use(express.static(path.join(__dirname, 'public')));

// Explicitly define routes for each HTML page. This is the fix for the "Cannot GET" errors.
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/index.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/how-it-works.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'how-it-works.html'));
});

app.get('/technology-deep-dive.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'technology-deep-dive.html'));
});

app.get('/applications.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'applications.html'));
});

app.get('/threats.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'threats.html'));
});

app.get('/protection.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'protection.html'));
});

app.get('/ai-analyzer.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'ai-analyzer.html'));
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running successfully on http://localhost:${port}`);
  console.log('Your website is now live at this address!');
});

